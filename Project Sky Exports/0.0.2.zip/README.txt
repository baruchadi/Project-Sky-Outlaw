** HOW TO RUN THE GAME **
WINDOWS: 

Run the run.bat file on windows, 

LINUX/MAC:

open terminal, write:
CD (path to the folder of the game)
java -jar game.jar

there will be stuff logged in a cmd panel, take a look if u wanna, it will tell you when a bullet is gone from the screen, how long it was from the last bullet shot, etc.

To open the game WITHOUT terminal / CMD prompt,

WINDOWS / MAC

double click game.jar

LINUX

wait until game released with official client, no other way was found by me yet, if you do find one, feel free to tell me it.

** CONTROLS **

up - move up
down - move down...
right - move right...
left - move left...
z - jump
x - reload/shoot

** Random Variables **

reload time - 2sec
bullets per gun - 6
total guns - 2
total bullets -12

