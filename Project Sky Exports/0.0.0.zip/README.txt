** HOW TO RUN THE GAME **

Run the run.bat file on windows, 

there will be stuff logged in a cmd panel, take a look if u wanna, it will tell you when a bullet is gone from the screen, how long it was from the last bullet shot, etc.

** CONTROLS **

up - move up
down - move down...
right - move right...
left - move left...
z - jump
x - reload/shoot

** Random Variables **

reload time - 2sec
bullets per gun - 6
total guns - 2
total bullets -12

